require('babel-register')({
  ignore: /(node_modules)/
});

require('./server.js');
